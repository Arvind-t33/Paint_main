#ifndef QUIT
    #define QUIT
    #include "main.h"
   
    void freeCanvas(CanvasBoard Canvas); 

#endif 