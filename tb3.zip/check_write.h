#ifndef check_write
    #define check_write
   
    bool get_input(int numArgs, int writeArgs[numArgs]);

#endif 