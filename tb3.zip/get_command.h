#ifndef get_command
    #define get_command
    #include "main.h"
   
    bool getCommand(CanvasBoard Canvas, int *numRows, int *numCols); 

#endif 