#ifndef check_add
    #define check_add
   
    bool get_add_input(int numArgs, char *choice, int *num);

#endif 

