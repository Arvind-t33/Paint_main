#ifndef input_Val
    #define input_val

    bool isInputValid(int numArgs, char *inputArgs[]);
    bool isAllArgsNum(int numArgs, char* inputArgs[]);


#endif // FIXME: update header with final declaractions of input_val.c
