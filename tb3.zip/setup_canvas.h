#ifndef setup_canvas
    #define setup_canvas
    #include "main.h"

    char** createCanvas(int rows, int cols, char startChar);
    void showCanvas(CanvasBoard Canvas);
    

#endif