#ifndef structDef
    #define structDef
   
    typedef struct CanvasBoard_struct {
        char **body;
        int rows;
        int cols;
    }CanvasBoard; 

#endif 