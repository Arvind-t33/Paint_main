#ifndef quit
    #define quit
   
    void print_help();

#endif 